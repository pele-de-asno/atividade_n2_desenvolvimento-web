import express from "express";
import Item from "../models/Item.js";

const router = express.Router();

// LISTAR
router.get("/", async (req, res) => {
  const items = await Item.find();
  res.render("dashboard", { items });
});

// CRIAR
router.post("/create", async (req, res) => {
  await Item.create({ name: req.body.name, value: req.body.value });
  res.redirect("/dashboard");
});

// EDITAR (form)
router.get("/edit/:id", async (req, res) => {
  const item = await Item.findById(req.params.id);
  res.render("edit", { item });
});

// EDITAR (submit)
router.post("/edit/:id", async (req, res) => {
  await Item.findByIdAndUpdate(req.params.id, {
    name: req.body.name,
    value: req.body.value
  });
  res.redirect("/dashboard");
});

// DELETE
router.get("/delete/:id", async (req, res) => {
  await Item.findByIdAndDelete(req.params.id);
  res.redirect("/dashboard");
});

export default router;
