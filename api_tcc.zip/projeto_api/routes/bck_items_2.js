import express from "express";
import Item from "../models/Item.js";


const router = express.Router();


// Dashboard + Listagem
router.get("/", async (req, res) => {
const items = await Item.find().lean();
const count = await Item.countDocuments();


res.render("dashboard", { items, count });
});


// Criar novo
router.post("/", async (req, res) => {
await Item.create({
recvTime: new Date(),
attrName: req.body.attrName,
attrType: req.body.attrType,
attrValue: req.body.attrValue
});


res.redirect("/");
});


// Página de edição
router.get("/edit/:id", async (req, res) => {
const item = await Item.findById(req.params.id).lean();
res.render("edit", { item });
});


// Editando
router.post("/edit/:id", async (req, res) => {
await Item.findByIdAndUpdate(req.params.id, {
attrName: req.body.attrName,
attrType: req.body.attrType,
attrValue: req.body.attrValue
});


res.redirect("/");
});


// Deletar
router.get("/delete/:id", async (req, res) => {
await Item.findByIdAndDelete(req.params.id);
res.redirect("/");
});


export default router;
