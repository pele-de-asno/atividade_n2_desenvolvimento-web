import mongoose from "mongoose";

const ItemSchema = new mongoose.Schema({
  name: String,
  value: Number
});

export default mongoose.model("Item", ItemSchema, "sth_/_urn:ngsi-ld:Lamp:001_Lamp");
