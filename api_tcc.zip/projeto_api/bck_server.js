import express from "express";
import session from "express-session";
import bodyParser from "body-parser";
import mongoose from "mongoose";
import itemsRoutes from "./routes/items.js";

const app = express();

// Configurações
app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: true }));

app.use(
  session({
    secret: "chave-super-secreta",
    resave: false,
    saveUninitialized: false
  })
);

// Middleware de autenticação
function requireAuth(req, res, next) {
  if (!req.session.mongoURI) return res.redirect("/");
  next();
}


// PAGINA DE LOGIN
app.get("/", (req, res) => {
  res.render("login", { error: null });
});

// LOGIN POST
app.post("/login", async (req, res) => {
  const { user, pass } = req.body;

  const mongoURI = `mongodb://${user}:${pass}@192.168.10.131:27017/sth_smart?authSource=admin`;

  try {
    await mongoose.connect(mongoURI);
    req.session.mongoURI = mongoURI;
    res.redirect("/dashboard");
  } catch (err) {
    res.render("login", { error: "Falha ao autenticar no MongoDB." });
  }
});

// DASHBOARD
app.get("/dashboard", requireAuth, (req, res) => {
  res.redirect("/items");
});

// ROTAS CRUD
app.use("/items", requireAuth, itemsRoutes);

const PORT = 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
